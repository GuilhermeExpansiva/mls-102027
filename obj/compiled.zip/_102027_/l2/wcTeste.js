/// <mls fileReference="_102027_/l2/wcTeste.ts" enhancement="_102027_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html } from 'lit';
import { customElement, property } from 'lit/decorators.js';
import { CollabLitElement } from '/_102027_/l2/collabLitElement.js';
let WcTeste100000 = class WcTeste100000 extends CollabLitElement {
    constructor() {
        super(...arguments);
        this.name = 'Somebody';
    }
    render() {
        return html `<p> Hello, ${this.name} !</p>`;
    }
};
__decorate([
    property()
], WcTeste100000.prototype, "name", void 0);
WcTeste100000 = __decorate([
    customElement('wc-teste-102027')
], WcTeste100000);
export { WcTeste100000 };
