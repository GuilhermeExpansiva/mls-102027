/// <mls fileReference="_102027_/l2/customElement.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=custom-element.d.ts.maps.d.ts.map
