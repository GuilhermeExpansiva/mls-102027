/// <mls shortName="collabLitElement" project="102027" enhancement="_100554_enhancementLit" />
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { LitElement } from 'lit';
import { property } from 'lit/decorators.js';
import { globalState } from '/_102027_/l2/collabState.js';
/**
 * Class extending LitElement with CollabState functionality.
 */
export class CollabLitElement extends LitElement {
    constructor() {
        super(...arguments);
        this.globalVariation = globalState.globalVariation || 0;
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        super.updated(changedProperties);
        if (changedProperties.has('globalVariation') && changedProperties.get('globalVariation') !== undefined) {
            this.requestUpdate();
        }
    }
    getMessageKey(messages) {
        return getMessageKey(messages);
    }
    loadStyle(css) {
        if (!css)
            return;
        const tagName = this.tagName.toLowerCase();
        const alreadyAdded = document.head.querySelector(`style#${tagName}`);
        if (alreadyAdded) {
            alreadyAdded.textContent = css;
            return;
        }
        const style = document.createElement('style');
        style.id = tagName;
        style.textContent = css;
        document.head.appendChild(style);
    }
}
__decorate([
    property({ type: Number })
], CollabLitElement.prototype, "globalVariation", void 0);
export function getMessageKey(messages) {
    const keys = Object.keys(messages);
    if (!keys || keys.length < 1)
        throw new Error('Error Message not valid for international');
    const firstKey = keys[0];
    const lang = (document.documentElement.lang || '').toLowerCase();
    if (!lang)
        return firstKey;
    if (messages.hasOwnProperty(lang))
        return lang;
    const similarLang = keys.find((key) => lang.substring(0, 2) === key);
    if (similarLang)
        return similarLang;
    return firstKey;
}
