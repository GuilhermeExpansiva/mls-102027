/// <mls fileReference="_102027_/l2/asyncDirective.ts" enhancement="_blank" />
export * from '/_102027_/l2/directive.js';
