/// <mls fileReference="_102027_/l2/agents/materialize/agentMaterializeTest.ts" enhancement="_102027_/l2/enhancementAgent.ts"/>
import { getMaterializeOrchestrator } from '/_102027_/l2/agents/materialize/materializeOrchestrator.js';
export function createAgent() {
    return {
        agentName: "agentMaterializeTest",
        agentProject: 102027,
        agentFolder: "agents/materialize",
        agentDescription: "new agent",
        visibility: "public",
        beforePromptImplicit,
        beforePromptStep,
        afterPromptStep
    };
}
async function beforePromptImplicit(agent, context, userPrompt) {
    const paths = [];
    const inputs = [{ type: "system", content: system1 }];
    const addMessageAI = {
        type: "add-message-ai",
        request: {
            action: 'addMessageAI',
            agentName: agent.agentName,
            inputAI: inputs,
            taskTitle: '',
            threadId: context.message.threadId,
            userMessage: context.message.content,
            longTermMemory: {},
        },
        executionMode: {
            type: 'parallel',
            args: paths
        }
    };
    return [addMessageAI];
}
async function beforePromptStep(agent, context, parentStep, step, hookSequential, args) {
    if (!args)
        throw new Error(`[beforePromptStep] args invalid`);
    if (args.startsWith("@@")) {
        const continueParallel1 = {
            type: "prompt_ready",
            args,
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            hookSequential,
            parentStepId: parentStep.stepId,
            humanPrompt: '',
            systemPrompt: system1
        };
        return [continueParallel1];
    }
    console.info('--------agentMaterializeTest--------');
    const info = JSON.parse(args);
    console.info(info);
    const continueParallel = {
        type: "prompt_ready",
        args,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        hookSequential,
        parentStepId: parentStep.stepId,
        humanPrompt: JSON.stringify(info)
    };
    return [continueParallel];
}
async function afterPromptStep(agent, context, parentStep, step, hookSequential) {
    if (!agent || !context || !step)
        throw new Error(`[afterPromptStep] invalid params, agent:${!!agent}, context:${!!context}, step:${!!step}`);
    const payload = (step.interaction?.payload?.[0]);
    if (payload?.type !== 'flexible' || !payload.result)
        throw new Error(`[afterPromptStep] invalid payload: ${payload}`);
    let status = 'completed';
    const orch = getMaterializeOrchestrator(payload.result.path);
    const group = await orch.processGroup(payload.result.id);
    const newSteps = [];
    Object.keys(group).forEach((g) => {
        const info = group[g];
        const newStep = {
            type: "add-step",
            messageId: context.message.orderAt,
            threadId: context.message.threadId,
            taskId: context.task?.PK || '',
            parentStepId: 1,
            step: {
                type: 'agent',
                stepId: 0,
                interaction: null,
                status: 'waiting_human_input',
                nextSteps: [],
                agentName: g,
                prompt: '@@ ' + JSON.stringify(info),
                rags: [],
            },
            executionMode: { type: 'parallel', args: info.map((i) => JSON.stringify({ path: payload.result.path, item: i })) }
        };
        newSteps.push(newStep);
    });
    const updateStatus = {
        type: 'update-status',
        hookSequential,
        messageId: context.message.orderAt,
        threadId: context.message.threadId,
        taskId: context.task?.PK || '',
        parentStepId: parentStep.stepId,
        stepId: step.stepId,
        status
    };
    return [...newSteps, updateStatus];
}
const system1 = `
<!-- modelType: code-->
<!-- modelTypeList: geminiChat (2.5 pro), code (grok), deepseekchat, codeflash (gemini), deepseekreasoner, mini (4.1) ou nano (openai), codeinstruct (4.1), codereasoning(gpt5), code2 (kimi 2.5) -->

Return as requested by the output using the user's data


## Output format
You must return the object strictly as JSON
[[OutputSection]]

`;
//#endregion 
