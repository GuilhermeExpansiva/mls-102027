/// <mls fileReference="_102027_/l2/queryAssignedElements.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=query-assigned-elements.d.ts.map
