/// <mls fileReference="_102027_/l2/collabSpliterVerticalVarFixed.ts" enhancement="_102027_/l2/enhancementLit.ts"/>
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
import { html, LitElement } from 'lit';
import { customElement, property, query } from 'lit/decorators.js';
import { collab_chevron_down } from '/_100554_/l2/collabIcons.js';
let CollabSpliterVerticalVarFixed = class CollabSpliterVerticalVarFixed extends LitElement {
    constructor() {
        super(...arguments);
        this.fixedheight = '0';
        this.complementcolor = '#000';
        this.spliterHeight = 20;
        this.withresize = 'true';
        this.actualfixedheight = this.fixedheight;
        this.msize = '';
        this.isBottomPaneOpen = true;
        this.styles = `
    collab-spliter-vertical-var-fixed-100554 {
      display: flex;
      flex-direction: column;
      width: 100%;
      height: 100%;
      max-width: var(--max-width);
      max-height: var(--max-height);
      position: relative;
    }
    collab-spliter-vertical-var-fixed-100554 > .spliter {
      display: flex;
      justify-content: center;
      height: 20px;
      background-color: var(--complement-color);
      position: relative;
      z-index: 1;
    }
    collab-spliter-vertical-var-fixed-100554 > .spliter .spliter-button {
      display: flex;
      align-items: center;
      justify-content: center;
      width: 60px;
      height: 20px;
      background-color: var(--collab-nav-bg-2);
      cursor: pointer;
      position: relative;
      z-index: 1;
      border-top-left-radius: 5px;
      border-top-right-radius: 5px;
    }

    collab-spliter-vertical-var-fixed-100554 > .spliter .spliter-button i {
      transition: transform 0.8s ease;
    }

    collab-spliter-vertical-var-fixed-100554 > .spliter .spliter-button.closed i {
      transform: rotate(180deg);
    }

    collab-spliter-vertical-var-fixed-100554 > .spliter .spliter-button i {
      cursor: pointer;
    }

    collab-spliter-vertical-var-fixed-100554 > .top-pane, .bottom-pane {
      overflow: auto;
    }
    collab-spliter-vertical-var-fixed-100554 > .top-pane {
      overflow:hidden;
      background-color: var(--complement-color);
      flex-grow: 1;
    }
    collab-spliter-vertical-var-fixed-100554 > .bottom-pane {
      overflow: hidden;
      background-color: var(--collab-nav-bg-2);
      max-height: var(--fixed-height);
      height: var(--bottom-pane-height, var(--fixed-height));
    }
    collab-spliter-vertical-var-fixed-100554 > .bottom-pane.closed {
      transition: height 0s;
      height: 0;
    }
  `;
    }
    createRenderRoot() {
        return this;
    }
    updated(changedProperties) {
        if (changedProperties.has('msize'))
            this._applyMSize();
        if (changedProperties.has('fixedheight')) {
            this.actualfixedheight = this.fixedheight;
            this.style.setProperty('--fixed-height', this.fixedheight + 'px');
            if (this.isBottomPaneOpen) {
                this.style.setProperty('--bottom-pane-height', this.fixedheight + 'px');
            }
            this.updatePanelsMSize();
        }
        if (changedProperties.has('complementcolor')) {
            this.style.setProperty('--complement-color', this.complementcolor);
        }
    }
    disconnectedCallback() {
        super.disconnectedCallback();
        if (this.resizeObserver)
            this.resizeObserver.disconnect();
    }
    firstUpdated() {
        this._distributeContent();
        this._applyMSize();
    }
    getMSize() {
        const [w, h, t, l] = this.msize.split(',');
        return {
            heigth: h,
            width: w,
            top: t,
            left: l
        };
    }
    getMSizeTop() {
        const msize = this.getMSize();
        let newHeight = '';
        let newMsize = [];
        if (this.withresize === 'true')
            newHeight = (+(msize.heigth) - (+this.actualfixedheight) - (this.spliterHeight)).toString();
        else
            newHeight = (+(msize.heigth) - (+this.actualfixedheight)).toString();
        newMsize = [msize.width, `${newHeight}`, msize.top, msize.left];
        return newMsize.join(',');
    }
    getMSizeBottom() {
        const msize = this.getMSize();
        let newHeight = '';
        let newMsize = [];
        newHeight = this.actualfixedheight;
        newMsize = [msize.width, `${newHeight}`, msize.top, msize.left];
        return newMsize.join(',');
    }
    updatePanelsMSize() {
        this.forceRefreshMsize(this.slotTop);
        this.forceRefreshMsize(this.slotBottom);
        setTimeout(() => {
            this.slotTop?.setAttribute('msize', this.getMSizeTop());
            this.slotBottom?.setAttribute('msize', this.getMSizeBottom());
        }, 50);
    }
    forceRefreshMsize(el) {
        if (!el)
            return;
        const msize = el.getAttribute('msize');
        if (!msize)
            return;
        let [w, h, t, l] = msize.split(',');
        l = ((+l) + 1).toString();
        el.setAttribute('msize', [w, h, t, l].join(','));
    }
    _applyMSize() {
        const [maxWidth, maxHeight] = this.msize.split(',').map(Number);
        if (!isNaN(maxHeight) && !isNaN(maxWidth)) {
            this.style.setProperty('--max-width', `${maxWidth}px`);
            this.style.setProperty('--max-height', `${maxHeight}px`);
        }
        this.updatePanelsMSize();
    }
    _onSpliterClick(event) {
        const spliter = event.target;
        const button = spliter.closest('.spliter-button');
        if (button) {
            const bottomPane = this.querySelector('.bottom-pane');
            this.isBottomPaneOpen = !this.isBottomPaneOpen;
            if (this.isBottomPaneOpen) {
                bottomPane.classList.remove('closed');
                button.classList.remove('closed');
                this.actualfixedheight = this.fixedheight;
                this.style.setProperty('--bottom-pane-height', this.fixedheight + 'px');
            }
            else {
                this.actualfixedheight = '0';
                bottomPane.classList.add('closed');
                button.classList.add('closed');
                this.style.setProperty('--bottom-pane-height', '0px');
            }
            this.updatePanelsMSize();
        }
    }
    _distributeContent() {
        const topPane = this.querySelector('.top-pane');
        const bottomPane = this.querySelector('.bottom-pane');
        const children = Array.from(this.children);
        let msizeNew = this.msize;
        children.forEach(child => {
            const slotName = child.getAttribute('slot');
            if (slotName === 'top' && topPane) {
                topPane.appendChild(child);
                msizeNew = this.getMSizeTop();
                child.setAttribute('msize', msizeNew);
            }
            else if (slotName === 'bottom' && bottomPane) {
                msizeNew = this.getMSizeBottom();
                child.setAttribute('msize', msizeNew);
                bottomPane.appendChild(child);
                this.resizeObserver = new ResizeObserver((entries) => {
                    if (this.timeoutResize)
                        clearTimeout(this.timeoutResize);
                    this.timeoutResize = setTimeout(() => {
                        for (let entry of entries) {
                            this.fixedheight = entry.contentRect.height.toString();
                        }
                    }, 500);
                });
                if (this.resizeObserver)
                    this.resizeObserver.observe(child);
            }
        });
    }
    render() {
        return html `
      <div class="top-pane"></div>
      ${this.withresize === 'true' ?
            html `<div class="spliter">
          <div @click=${this._onSpliterClick} class="spliter-button">
            <i>${collab_chevron_down}</i>          
          </div>
        </div>
        ` : html ``}
      <div class="bottom-pane"></div>
      <style>${this.styles}</style>
    `;
    }
};
__decorate([
    property({ type: String })
], CollabSpliterVerticalVarFixed.prototype, "fixedheight", void 0);
__decorate([
    property({ type: String })
], CollabSpliterVerticalVarFixed.prototype, "complementcolor", void 0);
__decorate([
    property({ type: Number })
], CollabSpliterVerticalVarFixed.prototype, "spliterHeight", void 0);
__decorate([
    property({ type: String })
], CollabSpliterVerticalVarFixed.prototype, "withresize", void 0);
__decorate([
    property({ type: String })
], CollabSpliterVerticalVarFixed.prototype, "actualfixedheight", void 0);
__decorate([
    property({ type: String })
], CollabSpliterVerticalVarFixed.prototype, "msize", void 0);
__decorate([
    property()
], CollabSpliterVerticalVarFixed.prototype, "isBottomPaneOpen", void 0);
__decorate([
    query('[slot="top"]')
], CollabSpliterVerticalVarFixed.prototype, "slotTop", void 0);
__decorate([
    query('[slot="bottom"]')
], CollabSpliterVerticalVarFixed.prototype, "slotBottom", void 0);
CollabSpliterVerticalVarFixed = __decorate([
    customElement('collab-spliter-vertical-var-fixed-102027')
], CollabSpliterVerticalVarFixed);
export { CollabSpliterVerticalVarFixed };
