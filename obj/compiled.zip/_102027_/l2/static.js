/// <mls shortName="static" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=static.d.ts.map
