/// <mls fileReference="_102027_/l2/static.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=static.d.ts.map
