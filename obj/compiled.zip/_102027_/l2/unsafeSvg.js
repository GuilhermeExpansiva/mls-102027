/// <mls shortName="unsafeSvg" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=unsafe-svg.d.ts.map
