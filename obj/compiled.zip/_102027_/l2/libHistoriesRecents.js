/// <mls fileReference="_102027_/l2/libHistoriesRecents.ts" enhancement="_blank"/>
const localStorageHistoryKeyPrefix = 'mlsInfoHistoryL';
function getStorageKey() {
    return localStorageHistoryKeyPrefix + mls.actualLevel;
}
function loadHistory() {
    const info = localStorage.getItem(getStorageKey());
    return info ? JSON.parse(info) : [];
}
function saveHistory(history) {
    localStorage.setItem(getStorageKey(), JSON.stringify(history));
}
function isSameFile(a, b) {
    return (a.project === b.project &&
        a.shortName === b.shortName &&
        a.folder === b.folder);
}
export function addInHistory(file) {
    const history = loadHistory();
    const newItem = {
        project: file.project,
        shortName: file.shortName,
        extension: file.extension,
        folder: file.folder,
    };
    let idx = -1;
    history.forEach((i, index) => {
        if (i.project !== file.project || i.shortName !== file.shortName || i.folder !== file.folder)
            return;
        idx = index;
    });
    if (idx >= 0)
        history.splice(idx, 1);
    history.unshift(newItem);
    if (history.length > 10) {
        for (let i = history.length - 1; i >= 0; i--) {
            if (history.length <= 10)
                break;
            history.splice(i, 1);
        }
    }
    saveHistory(history);
}
export function getHistory() {
    return loadHistory();
}
export function removeFromHistory(target) {
    const history = loadHistory();
    const updated = history.filter(item => !isSameFile(item, target));
    saveHistory(updated);
}
export function renameHistoryItem(target, newShortName) {
    const history = loadHistory();
    const updated = history.map(item => {
        if (isSameFile(item, target)) {
            return {
                ...item,
                shortName: newShortName,
            };
        }
        return item;
    });
    saveHistory(updated);
}
// Recents Projects
const localStorageHistoryKeyProject = 'serviceExploreProjects';
export function loadProjectHistory() {
    const lcHistory = localStorage.getItem(localStorageHistoryKeyProject);
    let rc = [];
    if (!lcHistory)
        return rc;
    try {
        rc = JSON.parse(lcHistory);
    }
    catch (err) {
        throw new Error('Error on load l5 project history');
    }
    return rc;
}
export function saveProjectHistory(history) {
    localStorage.setItem(localStorageHistoryKeyProject, JSON.stringify(history));
}
export function removeProjectFromHistory(projectId) {
    const history = loadProjectHistory();
    const updated = history.filter(item => item.project !== projectId);
    saveProjectHistory(updated);
}
export function renameProjectInHistory(projectId, newName) {
    const history = loadProjectHistory();
    const updated = history.map(item => {
        if (item.project === projectId) {
            return {
                ...item,
                name: newName
            };
        }
        return item;
    });
    saveProjectHistory(updated);
}
