/// <mls shortName="queryAsync" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=query-async.d.ts.map
