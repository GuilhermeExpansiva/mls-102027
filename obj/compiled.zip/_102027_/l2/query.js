/// <mls shortName="query" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=query.d.ts.map
