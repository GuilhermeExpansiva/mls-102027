/// <mls fileReference="_102027_/l2/query.ts" enhancement="_blank" />
export {};
//# sourceMappingURL=query.d.ts.map
