/// <mls shortName="until" project="102027" enhancement="_blank" />
export {};
/**
 * The type of the class that powers this directive. Necessary for naming the
 * directive's return type.
 */
//# sourceMappingURL=until.d.ts.map
