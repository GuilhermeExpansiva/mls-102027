/// <mls fileReference="_102027_/l2/until.ts" enhancement="_blank" />
export {};
/**
 * The type of the class that powers this directive. Necessary for naming the
 * directive's return type.
 */
//# sourceMappingURL=until.d.ts.map
