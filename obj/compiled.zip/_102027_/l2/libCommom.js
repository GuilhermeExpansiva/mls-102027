/// <mls fileReference="_102027_/l2/libCommom.ts" enhancement="_blank"/>
import { getMessageKey } from "/_102027_/l2/collabLitElement.js";
import { getPath } from '/_102027_/l2/utils.js';
/// **collab_i18n_start** 
const message_pt = {
    updatedToday: 'atualizado hoje',
    updated: 'atualizado',
    on: 'em',
    days: 'dias',
    day: 'dia',
    ago: 'atrás',
    jan: 'Jan',
    feb: 'Fev',
    mar: 'Mar',
    apr: 'Abr',
    may: 'Mai',
    june: 'Jun',
    july: 'Jul',
    aug: 'Ago',
    sept: 'Set',
    oct: 'Out',
    nov: 'Nov',
    dec: 'Dez',
};
const message_en = {
    updatedToday: 'updated today',
    updated: 'updated',
    on: 'on',
    days: 'days',
    day: 'day',
    ago: 'ago',
    jan: 'Jan',
    feb: 'Feb',
    mar: 'Mar',
    apr: 'Apr',
    may: 'May',
    june: 'June',
    july: 'July',
    aug: 'Aug',
    sept: 'Sept',
    oct: 'Oct',
    nov: 'Nov',
    dec: 'Dec',
};
const messages = {
    'en': message_en,
    'pt': message_pt
};
/// **collab_i18n_end**
const lang = getMessageKey(messages);
const msg = messages[lang];
export function getMyKeysBranch(project) {
    try {
        if (!mls.stor.projects[project])
            throw new Error('Not found projectInfo:' + project);
        const obj = mls.l5.getProjectDetails(project);
        if (!obj || !obj.value)
            throw new Error('Error getProjectDetails in:' + project);
        const json = JSON.parse(obj.value);
        if (!json)
            throw new Error('Error getProjectDetails .value json in:' + project);
        let info = '';
        if (!json.projectURL && json.l5_actionPrjSettings)
            info = json.l5_actionPrjSettings.projectURL;
        else if (json.projectURL)
            info = json.projectURL;
        else
            throw new Error('Error project info:' + project);
        if (info.endsWith('/'))
            info = info.substring(0, info.length - 1);
        const array = info.split('/');
        if (array.length < 3)
            throw new Error('Insufficient information to progress');
        return { branch: array[array.length - 3], owner: array[array.length - 2], repo: array[array.length - 1] };
    }
    catch (e) {
        throw new Error('Error get info branch: ' + e.message);
    }
}
export function createPath(project, shortName, folder) {
    if (!folder)
        return `_${project}_${shortName}`;
    else
        return `_${project}_${folder}/${shortName}`;
}
export function generateCompactTimestamp() {
    const now = new Date();
    const year = now.getFullYear();
    const month = String(now.getMonth() + 1).padStart(2, '0'); // Month is 0-based, so +1
    const day = String(now.getDate()).padStart(2, '0');
    const hours = String(now.getHours()).padStart(2, '0');
    const minutes = String(now.getMinutes()).padStart(2, '0');
    const seconds = String(now.getSeconds()).padStart(2, '0');
    const milliseconds = String(now.getMilliseconds()).padStart(3, '0');
    return `${year}${month}${day}${hours}${minutes}${seconds}${milliseconds}`;
}
export function getDateFormated(dt) {
    let lastUpdated;
    const dateToday = new Date();
    const dtLastWrite = new Date(dt);
    const _MS_PER_DAY = 1000 * 60 * 60 * 24;
    // a and b are javascript Date objects
    function dateDiffInDays(a, b) {
        // Discard the time and time-zone information.
        const utc1 = Date.UTC(a.getFullYear(), a.getMonth(), a.getDate());
        const utc2 = Date.UTC(b.getFullYear(), b.getMonth(), b.getDate());
        return Math.floor((utc2 - utc1) / _MS_PER_DAY);
    }
    const diffDays = dateDiffInDays(dtLastWrite, dateToday);
    const moreThanTwoDays = diffDays > 1;
    if (diffDays === 0) {
        lastUpdated = msg.updatedToday;
    }
    else if (diffDays < 30) {
        lastUpdated = `${msg.updated} ${diffDays} ${moreThanTwoDays ? msg.days : msg.day} ${msg.ago}`;
    }
    else {
        const lastWriteYear = dtLastWrite.getFullYear();
        const lastWriteMounth = dtLastWrite.getMonth();
        const lastWriteDay = dtLastWrite.getDate();
        const mounthFilter = {
            0: msg.jan,
            1: msg.feb,
            2: msg.mar,
            3: msg.apr,
            4: msg.may,
            5: msg.june,
            6: msg.july,
            7: msg.aug,
            8: msg.sept,
            9: msg.oct,
            10: msg.nov,
            11: msg.dec,
        };
        lastUpdated = `${msg.updated} ${msg.on} ${lastWriteYear}, ${lastWriteDay} ${mounthFilter[lastWriteMounth]} `;
    }
    return lastUpdated;
}
const iconCollabDefault = `data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHhtbG5zPSJodHRwOi8vd3d3LnczLm9yZy8yMDAwL3N2ZyI+CiAgPHJlY3QgeD0iMCIgeT0iMCIgd2lkdGg9IjYwIiBoZWlnaHQ9IjYwIiBmaWxsPSJ0cmFuc3BhcmVudCIgLz4KICA8dGV4dCB4PSIzMCIgeT0iNTYiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjcyIiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iIzQyODVGNCI+QzwvdGV4dD4KICA8dGV4dCB4PSI0MCIgeT0iNDAiIGZvbnQtZmFtaWx5PSJWZXJkYW5hIiBmb250LXNpemU9IjM4IiB0ZXh0LWFuY2hvcj0ibWlkZGxlIiBmb250LXdlaWdodD0iYm9sZCIgZmlsbD0iI0VBNDMzNSI+YzwvdGV4dD4KPC9zdmc+Cg==`;
const iconCollabNotification = `data:image/svg+xml;utf8,<svg width="60" height="60" xmlns="http://www.w3.org/2000/svg"><rect x="0" y="0" width="60" height="60" fill="transparent"/><text x="30" y="56" font-family="Verdana" font-size="72" text-anchor="middle" font-weight="bold" fill="%234285F4">C</text><text x="40" y="40" font-family="Verdana" font-size="38" text-anchor="middle" font-weight="bold" fill="%23EA4335">c</text><circle cx="50" cy="10" r="12" fill="%23FF0000"/></svg>
`;
export function changeFavIcon(notification) {
    const link = document.querySelector("#collabcodes_icon[rel~='icon']");
    if (!link)
        return;
    link.href = notification ? iconCollabNotification : iconCollabDefault;
}
export function checkIfHasLocalProject() {
    const hasFilePrjLocal = Object.values(mls.stor.files).find((item) => item.project === mls.stor.LOCALPROJECTNUMBER);
    return !!hasFilePrjLocal;
}
const keyLocalProject = 'projectLocalName';
export function getLocalProjectName() {
    return localStorage.getItem(keyLocalProject) || '';
}
export function setLocalProjectName(prjName) {
    if (!prjName)
        localStorage.removeItem(keyLocalProject);
    localStorage.setItem(keyLocalProject, prjName);
}
export function isValidProjectName(name) {
    if (!name || name.length <= 3)
        return false;
    const projectNameRegex = /^[a-zA-Z][a-zA-Z0-9_]*$/;
    return projectNameRegex.test(name);
}
export function escapeHTML(str) {
    return str
        .replace(/&/g, "&amp;")
        .replace(/"/g, "&quot;")
        .replace(/'/g, "&#039;")
        .replace(/</g, "&lt;")
        .replace(/>/g, "&gt;");
}
function delay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}
export async function openService(service, position, level, args) {
    const utils = await import('/_102027_/l2/utils');
    let page = top?.document.querySelector('collab-page');
    if (!page)
        return;
    const toolbar = page.querySelector(`collab-nav-2[toolbarposition="${position}"]`);
    if (!toolbar)
        return;
    if (mls.actualLevel !== level) {
        toolbar.state[level][position] = '';
        selectLevel(level);
        await delay(100);
    }
    const item = toolbar.querySelector(`collab-nav-2-item[data-service="${service}"]`);
    const itemNav3Content = page.querySelector(`collab-nav-3-service[data-service="${service}"]`);
    if (itemNav3Content && args) {
        const info = getPath(service);
        if (!info)
            throw new Error('[openService] Not found path:' + service);
        const { shortName, folder, project } = info;
        const tagService = utils.convertFileNameToTag({ shortName, folder, project });
        const serviceItem = itemNav3Content.querySelector(tagService);
        if (serviceItem) {
            Object.entries(args).forEach((arg) => {
                const [key, value] = arg;
                serviceItem.setAttribute(key, value);
            });
        }
    }
    if (item)
        item.click();
    return;
}
export function selectLevel(level) {
    const page = top?.document.querySelector('collab-page');
    const nav = page?.querySelector('collab-nav-1');
    const objIndex = {
        0: 7,
        1: 6,
        2: 5,
        3: 4,
        4: 3,
        5: 2,
        6: 1,
        7: 0,
    };
    if (!nav)
        return;
    nav.setAttribute('tabindexactive', objIndex[level]);
}
export async function forceServiceInstance(level, service) {
    const page = document.querySelector('collab-page');
    const nav = page?.querySelector('collab-nav-1');
    if (!nav)
        return;
    await nav.forceInstanceIfNeed([`${service};${level}`]);
}
export async function loadFileHTMLInContainer(el, shortName, project) {
    const libCompile = await import('/_102027_/l2/libCompile.js');
    const utils = await import('/_102027_/l2/utils');
    const keyFile = mls.stor.getKeyToFiles(project, 2, shortName, '', '.html');
    const storFile = mls.stor.files[keyFile];
    if (!storFile)
        throw new Error('File not founded');
    const content = await storFile.getContent();
    if (!content || typeof content !== 'string')
        throw new Error('File html invalid');
    el.innerHTML = '';
    const allWcs = libCompile.getAllWebComponentsInSource(content);
    el.innerHTML = content;
    allWcs.forEach((wc) => {
        const info = utils.convertTagToFileName(wc);
        if (info) {
            const script = document.createElement('script');
            script.type = 'module';
            script.id = info.shortName;
            script.src = (`/_${info.project}_${info.shortName}`);
            el.appendChild(script);
        }
    });
}
export function convertColorToHex(color) {
    const element = document.createElement('div');
    element.style.color = color.trim();
    document.body.appendChild(element);
    const computedColor = window.getComputedStyle(element).color;
    document.body.removeChild(element);
    if (!computedColor || !computedColor.startsWith('rgb')) {
        throw new Error(`Invalid color value: ${color}`);
    }
    const match = computedColor.match(/\d+/g);
    if (!match)
        return undefined;
    const rgbMatch = match.map(Number);
    const [r, g, b] = rgbMatch;
    return ('#' +
        [r, g, b]
            .map((val) => val.toString(16).padStart(2, '0'))
            .join('')
            .toUpperCase());
}
export async function getEnhancementName(file) {
    const key = mls.editor.getKeyModel(file.project, file.shortName, file.folder, file.level);
    const mmodel = mls.editor.models[key];
    if (!mmodel || !mmodel.ts)
        throw new Error('model invalid');
    if (!mmodel.ts.compilerResults)
        throw new Error('model ts not compiled yet');
    const enhacementName = mmodel.ts.compilerResults.tripleSlashMLS?.variables.enhancement;
    if (!enhacementName)
        throw new Error('enhacementName not valid');
    return enhacementName;
}
const BaseProject = 100554;
export async function loadPluginProject(project, scope, onlyEnabled = true) {
    await mls.plugin.loadAll(BaseProject, false);
    const base = mls.plugin.getAllMenuActions(BaseProject, { scope: scope });
    const deps = mls.l5.getProjectDependencies(project, false);
    let userMenuActions = [];
    for (let dep of [project, ...deps]) {
        await mls.plugin.loadAll(dep, false);
        const actionsMenu = mls.plugin.getAllMenuActions(dep, { scope: scope });
        userMenuActions = [...userMenuActions, ...actionsMenu];
    }
    const i = [...base, ...userMenuActions];
    return Array.from(new Map(i.map(obj => [JSON.stringify(obj), obj])).values());
}
const KeyProject = 'projectDetails';
export function setProjectDetails(project) {
    localStorage.setItem(KeyProject, JSON.stringify({ project }));
}
export function getProjectDetails() {
    return mls.stor.localStor.getProjectDetails();
}
export function calculateTotalStringSize(source, limitBase) {
    let totalBytes = 0;
    for (const text of source) {
        const encoded = new TextEncoder().encode(text);
        totalBytes += encoded.length;
    }
    const exceededLimit = totalBytes > limitBase;
    return {
        totalsize: totalBytes, // em bytes
        exceededLimit,
        sizeFormatted: formatSize(totalBytes)
    };
}
function formatSize(bytes) {
    if (bytes < 1024)
        return `${bytes}B`;
    if (bytes < 1024 * 1024)
        return `${(bytes / 1024).toFixed(2)}KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)}MB`;
}
export async function getListNewFilesToDeleteByFolder(project, folder, includeDist = false) {
    const filesToDelete = Object.values(mls.stor.files).filter(file => file.inLocalStorage &&
        (file.folder === folder || (includeDist && file.folder === `wwwroot/${folder}`)) &&
        file.project === project &&
        file.status === 'new');
    return filesToDelete;
}
export async function* deleteAllFilesLocal(filesToDelete) {
    const modelsToDelete = Array.from(new Map(filesToDelete.map(({ project, shortName, folder, level }) => [shortName, { project, shortName, folder, level }])).values());
    const filesToDeleteCache = new Set();
    for (const fileToDelete of filesToDelete) {
        await mls.stor.localStor.setContent(fileToDelete, { contentType: 'string', content: null });
        fileToDelete.onAction = undefined;
        fileToDelete.getValueInfo = undefined;
        const keyFiles = mls.stor.getKeyToFiles(fileToDelete.project, fileToDelete.level, fileToDelete.shortName, fileToDelete.folder, fileToDelete.extension);
        delete mls.stor.files[keyFiles];
        yield `Storfile deleted: ${keyFiles}`;
        const ext = fileToDelete.extension.replace('.ts', '.js');
        let targetKey = `https://collab.codes/local/_${fileToDelete.project}_${fileToDelete.shortName}${ext}?v=`;
        if (fileToDelete.folder)
            targetKey = `https://collab.codes/local/_${fileToDelete.project}_${fileToDelete.folder}/${fileToDelete.shortName}${ext}?v=`;
        filesToDeleteCache.add(targetKey);
    }
    for (const data of modelsToDelete) {
        const keyModel = mls.editor.getKeyModel(data.project, data.shortName, data.folder, data.level);
        mls.editor.deleteModels(data.project, data.shortName, data.folder, true, data.level);
        yield `Model deleted : ${keyModel}`;
    }
    const cacheName = 'mls-v2';
    const cache = await caches.open(cacheName);
    const keys = await cache.keys();
    for (const request of keys) {
        for (const targetKey of filesToDeleteCache) {
            if (request.url.includes(targetKey)) {
                await cache.delete(request);
                yield `Cache file deleted: ${request.url}`;
            }
        }
    }
}
export async function loadModuleFromProjectOrDependency(name, folder, ext) {
    const prj = mls.actualProject;
    if (!prj)
        throw new Error('Not found project actual!');
    let key = mls.stor.getKeyToFiles(prj, 2, name.trim(), folder.trim(), ext);
    if (mls.stor.files[key])
        return (await import('/_102027_/l2/collabImport.js')).collabImport({ project: prj, shortName: name, folder: folder });
    const info = mls.l5.getProjectDetails(prj);
    if (!info && prj !== mls.stor.LOCALPROJECTNUMBER)
        throw new Error('Not found project details from actual project!');
    let deps = [];
    if (info)
        deps = info.prj_dependencies;
    else
        deps = [100554];
    let prjDep = 0;
    deps.forEach((dep) => {
        if (mls.stor.files[key])
            return;
        prjDep = dep;
        key = mls.stor.getKeyToFiles(dep, 2, name.trim(), folder.trim(), ext);
    });
    if (!mls.stor.files[key])
        throw new Error('File not found in any dependency!');
    return await await (await import('/_102027_/l2/collabImport.js')).collabImport({ project: prjDep, shortName: name.trim(), folder: folder.trim() });
}
export function findStorFileInProjectsOrDeps(projectActual, level, fileName, folder, extension) {
    const deps = mls.l5.getProjectDependencies(projectActual, false);
    const keyActual = mls.stor.getKeyToFiles(projectActual, level, fileName, folder, extension);
    let storFile = mls.stor.files[keyActual];
    if (storFile)
        return storFile;
    for (let dep of deps) {
        const keyDep = mls.stor.getKeyToFiles(dep, level, fileName, folder, extension);
        storFile = mls.stor.files[keyDep];
        if (storFile)
            break;
    }
    return storFile;
}
const STORAGE_KEY = '_100554_serviceInit';
export function saveOpenedFile(project, level, file) {
    if (level < 0 || level > 7) {
        console.warn('Invalid level');
        return;
    }
    const data = getAllUserOpenedFiles();
    if (!data[project]) {
        data[project] = {};
    }
    const currentLevelData = data[project][level];
    if (typeof file === 'object' &&
        file !== null &&
        typeof currentLevelData === 'object' &&
        currentLevelData !== null) {
        data[project][level] = {
            left: file.left ?? currentLevelData.left,
            right: file.right ?? currentLevelData.right,
        };
    }
    else {
        data[project][level] = file;
    }
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
export function getLastOpenedFiles(project) {
    const data = getAllUserOpenedFiles();
    return data[project] ?? {};
}
export function deleteLastOpenedFiles(project) {
    const data = getAllUserOpenedFiles();
    if (data[project])
        delete data[project];
    localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
}
function getAllUserOpenedFiles() {
    const raw = localStorage.getItem(STORAGE_KEY);
    return raw ? JSON.parse(raw) : {};
}
const STORAGE_KEY_MODULES = '_100554_modules';
export function getLastModule() {
    const dataStr = localStorage.getItem(STORAGE_KEY_MODULES);
    if (!dataStr)
        return;
    try {
        const modules = JSON.parse(dataStr);
        return modules;
    }
    catch (err) {
        return;
    }
}
export function setLastModule(project, moduleName) {
    try {
        let info = localStorage.getItem(STORAGE_KEY_MODULES);
        if (!info)
            info = '{}';
        info = JSON.parse(info);
        info[project] = moduleName;
        localStorage.setItem(STORAGE_KEY_MODULES, JSON.stringify(info));
    }
    catch (e) {
        console.info(e);
    }
}
export async function getBaseTemplate(file, enhancement = '_blank') {
    const utils = await import('/_102027_/l2/utils');
    const { project, shortName, folder, extension } = file;
    const folderString = folder ? `${folder}/` : '';
    const name = `_${project}_/l2/${folderString}${shortName}${extension}`;
    switch (file.extension) {
        case ('.ts'): return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n\n// typescript new file\n`;
        case ('.html'): return `<h1>${file.shortName}</h1>`;
        case ('.less'): return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n\n${utils.convertFileNameToTag({ project, shortName, folder })} {\n\n// Here your less\n\n }`;
        case ('.test.ts'): return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n\n import { ICANTest, ICANIntegration, ICANSchema  } from '/_100554_/l2/tsTestAST.js';\n export const integrations: ICANIntegration[] = [];\n export const tests: ICANTest[] = [];`;
        case ('.defs.ts'): return `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n\n`;
        default: return '';
    }
}
export function verifyNeedAddTripleslach(info, src, extension, enhancement = '_blank') {
    if (!['.ts', '.defs.ts', '.test.ts', '.less'].includes(extension))
        return src;
    if (enhancement === '_blank' && extension === '.ts')
        enhancement = '_102027_/l2/enhancementLit';
    if (enhancement === '_blank' && extension === '.less')
        enhancement = '_100554_enhancementStyle';
    const folder = info.folder ? `${info.folder}/` : '';
    const name = `_${info.project}_/l2/${folder}${info.shortName}${extension}`;
    const triple = `/// <mls fileReference="${name}" enhancement="${enhancement}"/>\n`;
    if (src.startsWith('/// <mls '))
        return src;
    return triple + src;
}
export async function getInstanceByFile(file) {
    try {
        let { project, shortName, folder, extension } = file;
        if (file.extension === '.ts')
            extension = '';
        let key = `/_${project}_/l2/${shortName}${extension}`;
        if (folder)
            key = `/_${project}_/l2/${folder}/${shortName}${extension}`;
        key = key.replace('.ts', '.js');
        const m = await import(key);
        return m;
    }
    catch (e) {
        return undefined;
    }
}
export function isNameValid(project, shortName, folder, level, extension) {
    let isValid = false;
    if (project === 0 || !project || project === null)
        return isValid;
    if (shortName === '' || !shortName || shortName === null)
        return isValid;
    if (shortName.length === 0 || shortName.length > 255)
        return isValid;
    if (/\s/.test(shortName))
        return false;
    if (/^\d+$/.test(shortName))
        return false;
    if (/^\d/.test(shortName))
        return false;
    if (folder && /\s/.test(folder))
        return false;
    if (folder && /^\d+$/.test(folder))
        return false;
    if (folder && /^\d/.test(folder))
        return false;
    const invalidCharactersShortName = /[_\/{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
    if (invalidCharactersShortName.test(shortName))
        return isValid;
    const key = mls.stor.getKeyToFiles(project, level, shortName, folder, extension);
    let find = false;
    const keys = Object.keys(mls.stor.files);
    for (const k of keys) {
        if (key.toLocaleLowerCase() === k.toLocaleLowerCase())
            find = true;
    }
    if (mls.stor.files[key] || find)
        return isValid;
    const invalidsFolderAndName = ['l1', 'l2', 'l3', 'l4', 'l5', 'l6', 'l7', 'collab'];
    if (invalidsFolderAndName.includes(shortName.toLocaleLowerCase()))
        return isValid;
    if (folder) {
        let isValidFolder = true;
        if (folder.startsWith('_') && level !== 1)
            return isValid;
        for (const inv of invalidsFolderAndName) {
            if (folder.indexOf(inv) >= 0)
                isValidFolder = false;
        }
        if (!isValidFolder)
            return isValid;
        if (hasInvalidCharacter(`${folder}/${shortName}`))
            return isValid;
    }
    return true;
}
function hasInvalidCharacter(name) {
    const invalidCharacters = /[\{}\[\]\*$@#=\-+!|?,<>=.;^~º°""''``áàâãéèêíïóôõöúçñÁÀÂÃÉÈÍÏÓÔÕÖÚÇÑ]/;
    if (invalidCharacters.test(name) || name.indexOf("\\") >= 0)
        return true;
    return false;
}
export async function openElementInServiceDetails(el) {
    const serviceDetails = mls.services['100554_serviceDetail_right'];
    if (!serviceDetails)
        return;
    serviceDetails.openMe();
    serviceDetails.updateContentPluginWithElement(el);
}
export async function clearServiceDetails() {
    const serviceDetails = mls.services['100554_serviceDetail_right'];
    if (!serviceDetails)
        return;
    serviceDetails.clear();
}
export async function getProjectConfig(project) {
    const moduleProject = await (await import('/_102027_/l2/collabImport.js')).collabImport({ folder: '', project, shortName: 'project', extension: '.ts' });
    ;
    if (!moduleProject)
        return undefined;
    return moduleProject.projectConfig;
}
export async function getProjectModuleConfig(path, project) {
    const moduleConfig = await (await import('/_102027_/l2/collabImport.js')).collabImport({ folder: path, project, shortName: 'module', extension: '.ts' });
    if (!moduleConfig)
        return undefined;
    return moduleConfig.moduleConfig;
}
