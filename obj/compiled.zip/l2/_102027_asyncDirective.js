/// <mls shortName="asyncDirective" project="102027" enhancement="_blank" />
export * from '/_102027_/directive.js';
//# sourceMappingURL=async-directive.d.ts.map
