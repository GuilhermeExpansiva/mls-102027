/// <mls shortName="asyncDirective" project="102027" enhancement="_blank" />
export * from '/_100000_/directive.js';
//# sourceMappingURL=async-directive.d.ts.map
