/// <mls shortName="reactiveElement" project="102027" enhancement="_blank" />
export * from '/_100000_cssTag.js';
//# sourceMappingURL=reactive-element.d.ts.map
