/// <mls shortName="queryAll" project="102027" enhancement="_blank" />
export {};
//# sourceMappingURL=query-all.d.ts.map
