/// <mls shortName="directive" project="102027" enhancement="_blank" />
export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from '/_100000_/litHtml.js';
//# sourceMappingURL=directive.d.ts.map
