/// <mls shortName="directive" project="102027" enhancement="_blank" />
export { AttributePart, BooleanAttributePart, ChildPart, ElementPart, EventPart, Part, PropertyPart, } from '/_102027_/litHtml.js';
//# sourceMappingURL=directive.d.ts.map
