/// <mls shortName="project" project="102027" enhancement="_100554_enhancementLit" groupName="other" />

export const projectConfig = {
    masterFrontEnd: {
        build: '',
        start: '',
        liveView: '',
    },
    masterBackEnd: {
        build: '',
        start: '',
        serverView: ''
    },
    modules: []
}